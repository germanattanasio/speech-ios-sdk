//
//  speexdec.h
//  watsonwl5FaceswatsonIphone
//
//  Created by hoai on 2/25/13.
//
//

#ifndef watsonwl5FaceswatsonIphone_speexdec_h
#define watsonwl5FaceswatsonIphone_speexdec_h



#endif


void spx2pcm(u_int8_t* spx, int spxLen, u_int8_t** pcm/*out*/, int* pcmLen/*out*/);
