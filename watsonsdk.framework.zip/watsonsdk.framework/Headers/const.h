#ifndef _CONST_H
#define _CONST_H

#define LOG_2 0.69314718055994530941723212145818
#define LOG10_e 0.434294
#define PI	3.141682654
#endif
